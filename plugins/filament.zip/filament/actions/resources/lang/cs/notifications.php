<?php

declare(strict_types=1);

return [
    'throttled' => [
        'title' => 'Příliš mnoho pokusů',
        'body' => 'Zkuste to prosím znovu za :seconds sekund.',
    ],
];

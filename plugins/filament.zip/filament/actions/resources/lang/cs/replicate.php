<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Duplikovat',

        'modal' => [

            'heading' => 'Duplikovat :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikovat',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Záznam duplikován',
            ],

        ],

    ],

];

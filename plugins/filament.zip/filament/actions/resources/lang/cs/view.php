<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Zobrazit',

        'modal' => [

            'heading' => 'Zobrazit :label',

            'actions' => [

                'close' => [
                    'label' => 'Zavřít',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'View',

        'modal' => [

            'heading' => 'View :label',

            'actions' => [

                'close' => [
                    'label' => 'Close',
                ],

            ],

        ],

    ],

];

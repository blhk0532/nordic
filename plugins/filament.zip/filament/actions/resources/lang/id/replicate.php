<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Duplikat data',

        'modal' => [

            'heading' => 'Duplikat :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikat data',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Data berhasil diduplikat',
            ],

        ],

    ],

];

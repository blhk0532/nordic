<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Vista',

        'modal' => [

            'heading' => 'Vista de :label',

            'actions' => [

                'close' => [
                    'label' => 'Tancar',
                ],

            ],

        ],

    ],

];

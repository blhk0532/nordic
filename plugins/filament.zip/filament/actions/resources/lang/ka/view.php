<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'დათვალიერება',

        'modal' => [

            'heading' => 'ათვალიერებთ :label',

            'actions' => [

                'close' => [
                    'label' => 'დახურვა',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Pregledaj',

        'modal' => [

            'heading' => 'Pregled :label',

            'actions' => [

                'close' => [
                    'label' => 'Zatvori',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Vis',

        'modal' => [

            'heading' => 'Vis :label',

            'actions' => [

                'close' => [
                    'label' => 'Luk',
                ],

            ],

        ],

    ],

];

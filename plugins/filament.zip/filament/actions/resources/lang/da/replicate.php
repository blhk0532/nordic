<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Repliker',

        'modal' => [

            'heading' => 'Repliker :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Repliker',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Replikeret',
            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Uredite',

        'modal' => [

            'heading' => 'Uredite :label',

            'actions' => [

                'save' => [
                    'label' => 'Sačuvajte',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Sačuvano',
            ],

        ],

    ],

];

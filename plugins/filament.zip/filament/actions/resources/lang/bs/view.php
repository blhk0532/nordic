<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Pregledajte',

        'modal' => [

            'heading' => 'Pregled :label',

            'actions' => [

                'close' => [
                    'label' => 'Zatvoriti',
                ],

            ],

        ],

    ],

];

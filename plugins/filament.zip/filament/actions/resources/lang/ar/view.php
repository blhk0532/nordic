<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'عرض',

        'modal' => [

            'heading' => 'عرض :label',

            'actions' => [

                'close' => [
                    'label' => 'إغلاق',
                ],

            ],

        ],

    ],

];

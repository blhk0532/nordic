<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'ያያይዙ',
        'modal' => [

            'heading' => ':labelን ያያይዙ',
            'fields' => [

                'record_id' => [

                    'label' => 'ሪከርድ',
                ],
            ],
            'actions' => [

                'attach' => [

                    'label' => 'ያያይዙ',
                ],
                'attach_another' => [

                    'label' => 'ያያይዙ & ሌላ ያያይዙ',
                ],
            ],
        ],
        'notifications' => [

            'attached' => [

                'title' => 'ተያይዞዋል',
            ],
        ],
    ],
];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'አዲስ :label',

        'modal' => [

            'heading' => ':labelን መዝግብ',
            'actions' => [

                'create' => [

                    'label' => 'መዝግብ',
                ],
                'create_another' => [

                    'label' => 'መዝግብ & ሌላ መዝግብ',
                ],
            ],
        ],
        'notifications' => [

            'created' => [

                'title' => 'ተመዝግቦዋል',
            ],
        ],
    ],
];

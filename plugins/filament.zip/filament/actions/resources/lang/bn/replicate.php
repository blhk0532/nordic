<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'প্রতিরূপ করুন',

        'modal' => [

            'heading' => ':label প্রতিরূপ করুন',

            'actions' => [

                'replicate' => [
                    'label' => 'প্রতিরূপ করুন',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'প্রতিরূপ তৈরি করা হয়েছে',
            ],

        ],

    ],

];

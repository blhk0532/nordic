<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => '보기',

        'modal' => [

            'heading' => ':label 보기',

            'actions' => [

                'close' => [
                    'label' => '닫기',
                ],

            ],

        ],

    ],

];

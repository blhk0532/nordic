<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => '복제',

        'modal' => [

            'heading' => ':label 복제',

            'actions' => [

                'replicate' => [
                    'label' => '복제',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => '복제 완료',
            ],

        ],

    ],

];

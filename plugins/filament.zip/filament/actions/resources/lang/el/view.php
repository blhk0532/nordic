<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Προβολή',

        'modal' => [

            'heading' => 'Προβολή :label',

            'actions' => [

                'close' => [
                    'label' => 'Άκυρο',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Αντιγραφή',

        'modal' => [

            'heading' => 'Αντιγραφή :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Αντιγραφή',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Αντιγράφηκε επιτυχώς',
            ],

        ],

    ],

];

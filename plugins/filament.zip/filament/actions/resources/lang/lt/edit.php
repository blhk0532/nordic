<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Redaguoti',

        'modal' => [

            'heading' => 'Redaguoti :label',

            'actions' => [

                'save' => [
                    'label' => 'Išsaugoti pakeitimus',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Išsaugota',
            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Peržiūrėti',

        'modal' => [

            'heading' => 'Peržiūrėti :label',

            'actions' => [

                'close' => [
                    'label' => 'Uždaryti',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Atkartoti',

        'modal' => [

            'heading' => 'Atkartoti :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Atkartoti',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Atkartota',
            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Dupliquer',

        'modal' => [

            'heading' => 'Dupliquer :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Dupliquer',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Enregistrement dupliqué',
            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'ویرایش',

        'modal' => [

            'heading' => 'ویرایش :label',

            'actions' => [

                'save' => [
                    'label' => 'ذخیره',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'ذخیره شد',
            ],

        ],

    ],

];

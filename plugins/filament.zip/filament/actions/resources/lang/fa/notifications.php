<?php

declare(strict_types=1);

return [

    'throttled' => [
        'title' => 'تلاش بیش از حد مجاز',
        'body' => 'لطفا بعد از :seconds ثانیه دوباره تلاش کنید.',
    ],

];

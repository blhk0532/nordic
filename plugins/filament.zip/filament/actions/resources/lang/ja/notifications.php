<?php

declare(strict_types=1);

return [

    'throttled' => [
        'title' => '試行回数が多すぎます',
        'body' => ':seconds 秒後に再試行してください。',
    ],

];

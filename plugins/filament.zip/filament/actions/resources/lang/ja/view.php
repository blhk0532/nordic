<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => '表示',

        'modal' => [

            'heading' => ':label 表示',

            'actions' => [

                'close' => [
                    'label' => '閉じる',
                ],

            ],

        ],

    ],

];

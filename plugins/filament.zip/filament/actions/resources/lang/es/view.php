<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Ver',

        'modal' => [

            'heading' => 'Vista de :label',

            'actions' => [

                'close' => [
                    'label' => 'Cerrar',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'throttled' => [
        'title' => 'Demasiados intentos',
        'body' => 'Por favor intente nuevamente en :seconds segundos.',
    ],

];

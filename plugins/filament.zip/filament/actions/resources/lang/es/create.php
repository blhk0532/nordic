<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Crear :label',

        'modal' => [

            'heading' => 'Crear :label',

            'actions' => [

                'create' => [
                    'label' => 'Crear',
                ],

                'create_another' => [
                    'label' => 'Crear y crear otro',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Creado',
            ],

        ],

    ],

];

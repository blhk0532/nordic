<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Behtîrna',

        'modal' => [

            'heading' => ':Label behtîrna',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Behtîrna',
                ],

                'attach_another' => [
                    'label' => 'Pakhat behtîra adang behtîr lehna',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Behtîr a ni e.',
            ],

        ],

    ],

];

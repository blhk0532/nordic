<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Tihdikna',

        'modal' => [

            'heading' => ':Label tihdikna',

            'actions' => [

                'save' => [
                    'label' => 'Thlâkthlengna',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'A in save e.',
            ],

        ],

    ],

];

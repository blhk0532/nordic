<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Enna',

        'modal' => [

            'heading' => ':Label enna',

            'actions' => [

                'close' => [
                    'label' => 'Khârna',
                ],

            ],

        ],

    ],

];

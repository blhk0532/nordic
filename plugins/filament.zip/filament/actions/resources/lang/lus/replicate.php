<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Anpui siamna',

        'modal' => [

            'heading' => ':Label anpui siamna',

            'actions' => [

                'replicate' => [
                    'label' => 'Anpui siamna',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Anpui siam ani e.',
            ],

        ],

    ],

];

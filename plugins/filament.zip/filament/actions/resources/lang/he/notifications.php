<?php

declare(strict_types=1);

return [

    'throttled' => [
        'title' => 'יותר מדי ניסיונות',
        'body' => 'אנא נסה שוב בעוד :seconds שניות.',
    ],

];

<?php

declare(strict_types=1);

return [

    'label' => 'Ներմուծել :label',

    'modal' => [

        'heading' => 'Ներմուծել :label',

        'form' => [

            'file' => [

                'label' => 'Ֆայլ',

                'placeholder' => 'Վերբեռնել CSV ֆայլը',

                'rules' => [
                    'duplicate_columns' => '{0} ֆայլը չպետք է պարունակի մեկից ավելի դատարկ սյունակի վերնագիր։ |{1,*} ֆայլը չպետք է պարունակի կրկնօրինակ սյունակի :columns վերնագրեր։',
                ],

            ],

            'columns' => [
                'label' => 'Սյունակներ',
                'placeholder' => 'Ընտրեք սյունակը',
            ],

        ],

        'actions' => [

            'download_example' => [
                'label' => 'Ներբեռնել CSV ֆայլի օրինակ',
            ],

            'import' => [
                'label' => 'Ներմուծել',
            ],

        ],

    ],

    'notifications' => [

        'completed' => [

            'title' => 'Ներմուծումն ավարտված է',

            'actions' => [

                'download_failed_rows_csv' => [
                    'label' => 'Ներբեռնել սխալ տողի տեղեկատվությունը|Ներբեռնել սխալ տողերի տեղեկատվությունը',
                ],

            ],

        ],

        'max_rows' => [
            'title' => 'Ներբեռնված CSV ֆայլը չափազանց մեծ է',
            'body' => 'Դուք չեք կարող միաժամանակ ներմուծել ավելի քան 1 տող։/ Դուք չեք կարող միաժամանակ ներմուծել ավելի քան :count տող։',
        ],

        'started' => [
            'title' => 'Ներմուծումը սկսվել է',
            'body' => 'Ձեր ներմուծումը սկսվել է, և 1 տողը կմշակվի հետին պլանում։|Ձեր ներմուծումը սկսվել է, և :count տող կվերամշակվեն հետին պլանում։',
        ],

    ],

    'example_csv' => [
        'file_name' => ':importer-example',
    ],

    'failure_csv' => [
        'file_name' => 'import-:import_id-:csv_name-failed-rows',
        'error_header' => 'սխալ',
        'system_error' => 'Համակարգի սխալ, խնդրում ենք կապվել սպասարկման կենտրոնի հետ։',
        'column_mapping_required_for_new_record' => 'Այս :attribute սյունակը համատեղված չէ ֆայլի սյունակում, բայց պահանջվում է նոր գրառումներ ստեղծելու համար։',
    ],

];

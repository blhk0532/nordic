<?php

declare(strict_types=1);

return [

    'throttled' => [
        'title' => 'Չափազանց շատ փորձեր',
        'body' => 'Խնդրում ենք կրկին փորձել :seconds վայրկյան հետո։',
    ],

];

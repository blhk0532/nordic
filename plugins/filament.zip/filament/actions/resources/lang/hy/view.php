<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Դիտել',

        'modal' => [

            'heading' => 'Դիտել :labelը',

            'actions' => [

                'close' => [
                    'label' => 'Փակել',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Anzeigen',

        'modal' => [

            'heading' => ':label anzeigen',

            'actions' => [

                'close' => [
                    'label' => 'Schließen',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => ':label Yarat',

        'modal' => [

            'heading' => ':label yarat',

            'actions' => [

                'create' => [
                    'label' => 'Yarat',
                ],

                'create_another' => [
                    'label' => 'Yarat və başqasını yarat',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Yaradıldı',
            ],

        ],

    ],

];

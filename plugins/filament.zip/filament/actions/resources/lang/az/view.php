<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'Göstər',

        'modal' => [

            'heading' => ':label göstər',

            'actions' => [

                'close' => [
                    'label' => 'Bağla',
                ],

            ],

        ],

    ],

];

<?php

declare(strict_types=1);

return [

    'throttled' => [
        'title' => 'Túl sok próbálkozás',
        'body' => 'Kérjük próbáld újra :seconds másodperc múlva.',
    ],

];

<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'جیاکردنەوە',

        'modal' => [

            'heading' => 'جیاکردنەوەی :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'جیاکردنەوە',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'جیاکرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'جیاکردنەوەی هەڵبژێردراوەکان',

        'modal' => [

            'heading' => 'جیاکردنەوەی هەڵبژێردراوەکانی :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'جیاکردنەوە',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'جیاکرایەوە',
            ],

        ],

    ],

];

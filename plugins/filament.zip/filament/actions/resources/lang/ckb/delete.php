<?php

declare(strict_types=1);

return [

    'single' => [

        'label' => 'سڕینەوە',

        'modal' => [

            'heading' => 'سڕینەوەی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'سڕینەوەی هەڵبژێردراوەکان',

        'modal' => [

            'heading' => 'سڕینەوەی هەڵبژێردراوەکانی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

];
